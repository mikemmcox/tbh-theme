<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Output status messages to the browser
function output_status($message) {
    echo $message . "<br>";
    flush(); // Ensure the message is sent to the browser
}

// Include WordPress and WooCommerce functions
define('WP_USE_THEMES', false);
require('/home/tlmtdev/public_html/tbh.tlmt-dev.co.uk/wp-load.php'); // Update with the path to your wp-load.php

// CSV file paths (Global scope)
$main_product_csv_path = '/home/tlmtdev/public_html/tbh.tlmt-dev.co.uk/wp-content/themes/tlmt-child/feed/wordpressdatafullparent.csv'; // Update with the path to your main product CSV file
$variations_csv_path = '/home/tlmtdev/public_html/tbh.tlmt-dev.co.uk/wp-content/themes/tlmt-child/feed/wordpressdatafullvariations.csv'; // Update with the path to your variations CSV file

// Check if the file exists and is readable
function check_file($file_path) {
    if (!file_exists($file_path)) {
        output_status("CSV file does not exist: $file_path");
        return false;
    }
    if (!is_readable($file_path)) {
        output_status("CSV file is not readable: $file_path");
        return false;
    }
    return true;
}

// Create or update product attributes
function set_product_attributes($product, $attributes) {
    foreach ($attributes as $key => $value) {
        if (!empty($value)) {
            // For variable products, handle attributes separately
            if ($product instanceof WC_Product_Variable) {
                // Add attribute terms and set them
                $taxonomy = 'pa_' . sanitize_title($key);
                if (!taxonomy_exists($taxonomy)) {
                    register_taxonomy($taxonomy, 'product', array(
                        'hierarchical' => true,
                        'label' => ucfirst($key),
                        'query_var' => true,
                        'rewrite' => array('slug' => sanitize_title($key)),
                    ));
                }
                wp_set_object_terms($product->get_id(), sanitize_text_field($value), $taxonomy, true);
            } else {
                $product->set_attribute($key, $value);
            }
        }
    }
}

// Update or import main products in WooCommerce
function update_main_products() {
    global $main_product_csv_path; // Ensure the path is accessible

    output_status("Updating main products from CSV: $main_product_csv_path");

    if (!check_file($main_product_csv_path)) {
        return;
    }

    if (($handle = fopen($main_product_csv_path, "r")) !== FALSE) {
        $header = fgetcsv($handle); // Get the header row for column mapping
        if ($header === FALSE) {
            output_status("Failed to read CSV header");
            fclose($handle);
            return;
        }

        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            if (count($header) !== count($data)) {
                output_status("Column count mismatch");
                continue;
            }

            // Map CSV columns to variables
            $product_data = array_combine($header, $data);

            if ($product_data === FALSE) {
                output_status("Failed to combine CSV data");
                continue;
            }

            // Retrieve and sanitize product data
            $post_title = sanitize_text_field($product_data['post_title']);
            $post_excerpt = sanitize_textarea_field($product_data['post_excerpt']);
            $post_content = wp_kses_post($product_data['post_content']);
            $post_name = sanitize_title($product_data['post_name']);
            $post_status = sanitize_text_field($product_data['post_status']);
            $sku = sanitize_text_field($product_data['sku']);
            $stock_status = sanitize_text_field($product_data['stock_status']);
            $images = sanitize_text_field($product_data['images']);
            $product_type = sanitize_text_field($product_data['tax:product_type']);
            $product_cat = sanitize_text_field($product_data['tax:product_cat']);

            // Product attributes
            $attributes = [
                'pa_colour' => sanitize_text_field($product_data['attribute:Colour']),
                'pa_size' => sanitize_text_field($product_data['attribute:Size']),
                'pa_brand' => sanitize_text_field($product_data['attribute:pa_Brand']),
                'pa_gender' => sanitize_text_field($product_data['attribute:pa_Gender']),
                'pa_organic' => sanitize_text_field($product_data['attribute:pa_Organic']),
                'pa_jacket_length' => sanitize_text_field($product_data['attribute:pa_Jacket Length']),
                'pa_leg_length' => sanitize_text_field($product_data['attribute:pa_Leg Length']),
                'pa_fabricfilter' => sanitize_text_field($product_data['attribute:pa_FabricFilter']),
                'pa_weight' => sanitize_text_field($product_data['attribute:pa_Weight']),
                'pa_capacity' => sanitize_text_field($product_data['attribute:pa_Capacity']),
                'pa_accreditations' => sanitize_text_field($product_data['attribute:pa_Accreditations']),
                'pa_taginformation' => sanitize_text_field($product_data['attribute:pa_TagInformation']),
                'pa_availableinplussizes' => sanitize_text_field($product_data['attribute:pa_AvailableInPlusSizes']),
                'pa_agegroup' => sanitize_text_field($product_data['attribute:pa_AgeGroup']),
            ];

            // Custom attributes
            $acf_fields = [
                'size_description' => sanitize_text_field($product_data['attribute:Size Description']),
                'washing_instructions' => sanitize_text_field($product_data['attribute:Washing Instructions']),
                'size_exclusions' => sanitize_text_field($product_data['attribute:Size Exclusions']),
                'fabric_description' => sanitize_text_field($product_data['attribute:Fabric Description']),
                'dimensions' => sanitize_text_field($product_data['attribute:Dimensions']),
            ];

            $product_id = wc_get_product_id_by_sku($sku);

            if ($product_id) {
                // Update existing product
                $product = wc_get_product($product_id);
                output_status("Updating product ID: $product_id");
            } else {
                // Create new product based on type
                switch ($product_type) {
                    case 'simple':
                        $product = new WC_Product_Simple();
                        break;
                    case 'variable':
                        $product = new WC_Product_Variable();
                        break;
                    case 'grouped':
                        $product = new WC_Product_Grouped();
                        break;
                    case 'external':
                        $product = new WC_Product_External();
                        break;
                    default:
                        $product = new WC_Product();
                        output_status("Unknown product type: $product_type. Using default product.");
                        break;
                }
                $product->set_sku($sku);
                output_status("Creating new product with SKU: $sku");
            }

            // Set product properties
            $product->set_name($post_title);
            $product->set_description($post_content);
            $product->set_short_description($post_excerpt);
            $product->set_status($post_status);
            $product->set_category_ids(explode(',', $product_cat));
            $product->set_stock_status($stock_status);

            // Set product images
            $image_urls = explode(',', $images);
            $product->set_image_id($image_urls[0]); // Set the first image as the main product image
            if (count($image_urls) > 1) {
                $gallery_image_ids = array_slice($image_urls, 1);
                $product->set_gallery_image_ids($gallery_image_ids);
            }

            // Set attributes
            set_product_attributes($product, $attributes);

            // Set custom ACF fields
            foreach ($acf_fields as $field_key => $field_value) {
                if (!empty($field_value)) {
                    update_field($field_key, $field_value, $product->get_id()); // Use ACF function to set custom fields
                }
            }

            $product->save();
        }
        fclose($handle);
        output_status("Finished updating products");
    } else {
        output_status("Failed to open CSV file for products");
    }
}

// Update or import variations in WooCommerce
function update_variations() {
    global $variations_csv_path; // Ensure the path is accessible

    output_status("Updating variations from CSV: $variations_csv_path");

    if (!check_file($variations_csv_path)) {
        return;
    }

    if (($handle = fopen($variations_csv_path, "r")) !== FALSE) {
        $header = fgetcsv($handle); // Get the header row for column mapping
        if ($header === FALSE) {
            output_status("Failed to read CSV header");
            fclose($handle);
            return;
        }

        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            if (count($header) !== count($data)) {
                output_status("Column count mismatch");
                continue;
            }

            // Map CSV columns to variables
            $variation_data = array_combine($header, $data);

            if ($variation_data === FALSE) {
                output_status("Failed to combine CSV data");
                continue;
            }

            // Retrieve and sanitize variation data
            $parent_sku = sanitize_text_field($variation_data['parent_sku']);
            $sku = sanitize_text_field($variation_data['sku']);
            $stock_status = sanitize_text_field($variation_data['stock_status']);
            $regular_price = sanitize_text_field($variation_data['regular_price']);
            $tax_class = sanitize_text_field($variation_data['tax_class']);
            $images = sanitize_text_field($variation_data['images']);

            $attributes = [
                'pa_primarycolour' => sanitize_text_field($variation_data['attribute:pa_PrimaryColour']),
                'pa_colourname' => sanitize_text_field($variation_data['attribute:pa_ColourName']),
                'pa_colourshade' => sanitize_text_field($variation_data['attribute:pa_ColourShade']),
                'pa_filtersize' => sanitize_text_field($variation_data['attribute:pa_FilterSize']),
            ];

            $meta_attributes = [
                'attribute_colour' => sanitize_text_field($variation_data['meta:attribute_Colour']),
                'attribute_size' => sanitize_text_field($variation_data['meta:attribute_Size']),
            ];

            $parent_id = wc_get_product_id_by_sku($parent_sku);
            if ($parent_id) {
                $variation_id = wc_get_product_id_by_sku($sku);
                if ($variation_id) {
                    // Update existing variation
                    $variation = new WC_Product_Variation($variation_id);
                    output_status("Updating variation ID: $variation_id");
                } else {
                    // Create new variation
                    $variation = new WC_Product_Variation();
                    $variation->set_sku($sku);
                    $variation->set_parent_id($parent_id);
                    output_status("Creating new variation with SKU: $sku");
                }

                $variation->set_regular_price($regular_price);
                $variation->set_stock_status($stock_status);
                $variation->set_tax_class($tax_class);

                // Set variation images
                $image_urls = explode(',', $images);
                if (!empty($image_urls[0])) {
                    $variation->set_image_id($image_urls[0]);
                }

                // Set attributes
                foreach ($attributes as $key => $value) {
                    if (!empty($value)) {
                        $variation->set_attribute($key, $value);
                    }
                }

                // Set meta attributes
                foreach ($meta_attributes as $meta_key => $meta_value) {
                    if (!empty($meta_value)) {
                        $variation->update_meta_data($meta_key, $meta_value);
                    }
                }

                $variation->save();
            } else {
                output_status("Parent product not found for SKU: $parent_sku");
            }
        }
        fclose($handle);
        output_status("Finished updating variations");
    } else {
        output_status("Failed to open CSV file for variations");
    }
}

// Run the import process
function run_import() {
    output_status("Starting import process");

    // Process main products
    update_main_products();

    // Process variations
    update_variations();

    output_status("Import process completed");
}

// Execute the import process
run_import();

?>
